NeuroBreath Download Bundle
===========================
Build date: 2025-11-17

Included PDFs
-------------
* Autism Support Guide for Adults (UK)
* Autism Clinic Guide and Checklists (UK)
* Autism Later Life and Carer Guide (UK)
* Autism Parent Quick Guide (UK)
* Dyslexia Adult Resource Guide (UK)
* Dyslexia Parent Support Guide
* Dyslexia Practice Pack Templates
* Breathing Cheat Sheet
* Teacher Quick Pack
* One-Page Regulation Profile Template

Distribution Guidance
---------------------
- Share inside clinical, education, or peer support settings with credit to NeuroBreath.
- Do not edit clinical references without consulting subject matter experts.
- Contact hello@mindpaylink.com for updated editions or contribution notes.
